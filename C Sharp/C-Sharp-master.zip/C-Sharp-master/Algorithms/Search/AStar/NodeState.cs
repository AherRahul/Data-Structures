﻿namespace AStar
{
    /// <summary>
    /// The states the nodes can have.
    /// </summary>
    public enum NodeState
    {
        /// <summary>
        /// TODO.
        /// </summary>
        UNCONSIDERED = 0,

        /// <summary>
        /// TODO.
        /// </summary>
        OPEN = 1,

        /// <summary>
        /// TODO.
        /// </summary>
        CLOSED = 2,
    }
}
