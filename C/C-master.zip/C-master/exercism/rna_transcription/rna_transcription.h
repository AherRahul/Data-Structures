#ifndef __RNA_TRANSCRIPTION__H
#define __RNA_TRANSCRIPTION__H

/* to_rna: compiles a DNA strand in its RNA complement */
char * to_rna(const char s[]);

#endif